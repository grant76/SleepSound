package com.example.sleepsound;

public interface BLEControllerListener {
    public void BLEControllerConnected();
    public void BLEControllerDisconnected();
    public void timeout();
    public void BLEDeviceFound(String name, String address);
}