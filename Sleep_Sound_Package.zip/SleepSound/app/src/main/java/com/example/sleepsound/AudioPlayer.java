package com.example.sleepsound;

import android.media.MediaPlayer;
import android.util.Log;

public class AudioPlayer {
    private static AudioPlayer instance;
    private String filePath = "storage/emulated/0/Documents/";
    private String oceanWaves = "Ocean Waves.mp3";
    private String rainSounds = "Rain Sounds.mp3";
    private String selectedSound;
    private float maxFeatureValue;

    private MediaPlayer mp = new MediaPlayer();

    public static AudioPlayer getInstance() {
        if (null == instance)
            instance = new AudioPlayer();

        return instance;
    }

    private void prepareAudio() {
        try {
            mp.setDataSource(filePath + selectedSound);
            mp.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void resumeAudio() {
        mp.start();
    }

    public void pauseAudio() {
        mp.pause();
    }

    public void selectSound(String sound) {
        mp = new MediaPlayer();

        if (sound.equals("Ocean Waves")) {
            this.selectedSound = oceanWaves;
        }

        else if (sound.equals("Rain Sounds")) {
            this.selectedSound = rainSounds;
        }

        else {
            Log.i("[BLE]", "No such audio as " + sound);
        }

        prepareAudio();
    }

    public void setVolume(float featureValue) {
        if (featureValue > maxFeatureValue) {
            Log.i("[BLE]", "New max RMS value detected: " + featureValue);
            maxFeatureValue = featureValue;
        }

        float adjustedVolume = featureValue / maxFeatureValue;
        mp.setVolume(adjustedVolume, adjustedVolume);
    }
}