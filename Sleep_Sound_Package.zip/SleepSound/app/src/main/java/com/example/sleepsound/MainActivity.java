/*
 * (c) Matey Nenov (https://www.thinker-talk.com)
 *
 * Licensed under Creative Commons: By Attribution 3.0
 * http://creativecommons.org/licenses/by/3.0/
 *
 */

package com.example.sleepsound;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements BLEControllerListener {
    private Button connectButton;
    private Button disconnectButton;
    private Button playButton;
    private Button pauseButton;
    private TextView connectStatus;
    private TextView arduinoStatus;
    private RadioGroup soundLibrary;
    private RadioButton firstSound;
    private RadioButton secondSound;

    private BLEController bleController;
    private AudioPlayer audioPlayer;
    private String deviceAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.connectStatus = findViewById(R.id.connectStatus);
        this.arduinoStatus = findViewById(R.id.arduinoStatus);

        this.soundLibrary = findViewById(R.id.soundLibrary);
        this.firstSound = findViewById(R.id.firstSound);
        this.secondSound = findViewById(R.id.secondSound);

        this.bleController = BLEController.getInstance(this);
        this.audioPlayer = AudioPlayer.getInstance();

        initConnectButton();
        initDisconnectButton();
        initPlayButton();
        initPauseButton();
        initSoundLibrary();

        checkBLESupport();
        checkPermissions();

        scanState();
    }

    private void initConnectButton() {
        this.connectButton = findViewById(R.id.connectButton);
        this.connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setConnectStatus("Connecting...");
                bleController.connectToDevice(deviceAddress);

                connectButton.setEnabled(false);
            }
        });
    }

    private void initDisconnectButton() {
        this.disconnectButton = findViewById(R.id.disconnectButton);
        this.disconnectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setConnectStatus("Disconnecting...");
                bleController.disconnect();
                bleController.init();
            }
        });
    }

    private void initPlayButton() {
        this.playButton = findViewById(R.id.playButton);
        this.playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                audioPlayer.resumeAudio();

                playState();
            }
        });
    }

    private void initPauseButton() {
        this.pauseButton = findViewById(R.id.pauseButton);
        this.pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                audioPlayer.pauseAudio();

                connectedState();
            }
        });
    }

    private void initSoundLibrary() {
        this.soundLibrary = findViewById(R.id.soundLibrary);
        this.firstSound = findViewById(R.id.firstSound);
        this.secondSound = findViewById(R.id.secondSound);

        this.soundLibrary.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton selectedSound = group.findViewById(checkedId);
                if (selectedSound.getText().equals("Ocean Waves")) {
                    audioPlayer.selectSound("Ocean Waves");
                }
                else if (selectedSound.getText().equals("Rain Sounds")) {
                    audioPlayer.selectSound("Rain Sounds");
                }
            }
        });

        this.firstSound.setChecked(true);
    }

    private void setConnectStatus(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                connectStatus.setText(text);

                if (text.equals("Connected!")) {
                    connectStatus.setTextColor(Color.GREEN);
                }

                else if (text.equals("Failed!")) {
                    connectStatus.setTextColor(Color.RED);
                }

                else {
                    connectStatus.setTextColor(Color.LTGRAY);
                }
            }
        });
    }

    private void setArduinoStatus(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                arduinoStatus.setText(text);

                if (text.equals("Found!")) {
                    arduinoStatus.setTextColor(Color.GREEN);
                }

                else if (text.equals("Could not find Arduino!")) {
                    arduinoStatus.setTextColor(Color.RED);
                }

                else {
                    arduinoStatus.setTextColor(Color.LTGRAY);
                }
            }
        });
    }

    private void scanState() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setConnectStatus("Not connected!");
                setArduinoStatus("Searching...");

                connectButton.setEnabled(false);
                disconnectButton.setEnabled(false);
                playButton.setEnabled(false);
                pauseButton.setEnabled(false);

                soundLibrary.setEnabled(false);
                firstSound.setEnabled(false);
                secondSound.setEnabled(false);
            }
        });
    }

    private void foundState() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setArduinoStatus("Found!");

                connectButton.setEnabled(true);
            }
        });
    }

    private void connectedState() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setConnectStatus("Connected!");

                connectButton.setEnabled(false);
                disconnectButton.setEnabled(true);
                playButton.setEnabled(true);
                pauseButton.setEnabled(false);

                soundLibrary.setEnabled(true);
                firstSound.setEnabled(true);
                secondSound.setEnabled(true);
            }
        });
    }

    private void playState() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                playButton.setEnabled(false);
                pauseButton.setEnabled(true);

                soundLibrary.setEnabled(false);
                firstSound.setEnabled(false);
                secondSound.setEnabled(false);
            }
        });
    }

    public void timeout() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setConnectStatus("Failed!");
                setArduinoStatus("Could not find Arduino!");
            }
        });
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    42);
        }
    }

    private void checkBLESupport() {
        // Check if BLE is supported on the device.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "BLE not supported!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        if(!BluetoothAdapter.getDefaultAdapter().isEnabled()){
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBTIntent, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        this.deviceAddress = null;
        this.bleController = BLEController.getInstance(this);
        this.bleController.addBLEControllerListener(this);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            this.bleController.init();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        this.bleController.removeBLEControllerListener(this);
    }

    @Override
    public void BLEControllerConnected() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                connectedState();
            }
        });
    }

    @Override
    public void BLEControllerDisconnected() {
        setConnectStatus("Disconnected!");
        scanState();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                scanState();

                audioPlayer.pauseAudio();
            }
        });
    }

    @Override
    public void BLEDeviceFound(String name, String address) {
        this.deviceAddress = address;

        foundState();
    }
}